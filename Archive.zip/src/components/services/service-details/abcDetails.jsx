import Wrapper from '@/layout/wrapper'
import React from 'react'

const abcDetails = () => {
  return (
    <Wrapper>
      <h1>abc details page</h1>
    </Wrapper>
  )
}

export default abcDetails
