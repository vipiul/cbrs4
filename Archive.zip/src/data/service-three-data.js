const service_three_data = [
  {
    id: 1,
    img: "/assets/img/services/services-thumb-01.jpg",
    icon: "flaticon-hemoglobin-test-meter",
    color: "",
    title: "Hemoglobin Test",
  },
  {
    id: 2,
    img: "/assets/img/services/services-thumb-02.jpg",
    icon: "flaticon-blood-test",
    color: "pink-round",
    title: "Genarel Analysis",
  },
  {
    id: 3,
    img: "/assets/img/services/services-thumb-03.jpg",
    icon: "flaticon-biochemistry",
    color: "sky-round",
    title: "Biochemistry",
  },
  {
    id: 4,
    img: "/assets/img/services/services-thumb-04.jpg",
    icon: "flaticon-bacteria",
    color: "blue-round",
    title: "Hemoglobin Test",
  },
  {
    id: 5,
    img: "/assets/img/services/services-thumb-05.jpg",
    icon: "flaticon-dna-1",
    color: "",
    title: "histopatology",
  },
  {
    id: 6,
    img: "/assets/img/services/services-thumb-06.jpg",
    icon: "flaticon-dna",
    color: "pink-round",
    title: "Genetics",
  },
];
export default service_three_data;
