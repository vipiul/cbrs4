const feedback = [
  {
    id: 1,
    img: "assets/img/icon/testi-ava-01.jpg",
    name: "Darlene Robertson",
    title: " Secretary of (FlaxStudio)",
    des: (
      <>
        Exerci tation ullamcorper suscipit lobortis nisl aliquip ex
        ea commodo claritatem insitamconse quat.Exerci tation ullamcorper
        suscipit loborti excommodo habent claritatem insitamconse quat.Exerci
        tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat.
      </>
    ),
  },
  {
    id: 2,
    img: "assets/img/icon/testi-ava-02.jpg",
    name: "Courtney Henry",
    title: "CEO of (FlaxStudio)",
    des: (
      <>
        Exerci tation ullamcorper suscipit lobortis nisl aliquip ex
        ea commodo claritatem insitamconse quat.Exerci tation ullamcorper
        suscipit loborti excommodo habent claritatem insitamconse quat.Exerci
        tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat.
      </>
    ),
  },
  {
    id: 3,
    img: "assets/img/icon/testi-ava-03.jpg",
    name: "Kathryn Murphy",
    title: "Manager of (FlaxStudio)",
    des: (
      <>
       Exerci tation ullamcorper suscipit lobortis nisl aliquip ex
        ea commodo claritatem insitamconse quat.Exerci tation ullamcorper
        suscipit loborti excommodo habent claritatem insitamconse quat.Exerci
        tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat.
      </>
    ),
  },
  {
    id: 4,
    img: "assets/img/icon/testi-ava-07.png",
    name: "Darlene Robertson",
    title: "Programmer of (FlaxStudio)",
    des: (
      <>
        Exerci tation ullamcorper suscipit lobortis nisl aliquip ex
        ea commodo claritatem insitamconse quat.Exerci tation ullamcorper
        suscipit loborti excommodo habent claritatem insitamconse quat.Exerci
        tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat.
      </>
    ),
  },
];

export default feedback;
