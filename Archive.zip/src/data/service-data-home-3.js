const ServiceDataHomeThree = [
  {
    id: 1,
    img: "/assets/img/services/services-thumb-01.jpg",
    name: "Hemoglobin Test",
    icon: "flaticon-hemoglobin-test-meter",
    color: "",
  },
  {
    id: 2,
    img: "/assets/img/services/services-thumb-02.jpg",
    name: "Genarel Analysis",
    icon: "flaticon-blood-test",
    color: "pink-round",
  },
  {
    id: 3,
    img: "/assets/img/services/services-thumb-03.jpg",
    name: "Biochemistry",
    icon: "flaticon-biochemistry",
    color: "sky-round",
  },
  {
    id: 4,
    img: "/assets/img/services/services-thumb-04.jpg",
    name: "Hemoglobin Test",
    icon: "flaticon-bacteria",
    color: "blue-round",
  },
  {
    id: 5,
    img: "/assets/img/services/services-thumb-05.jpg",
    name: "histopatology",
    icon: "flaticon-dna-1",
    color: "",
  },
  {
    id: 6,
    img: "/assets/img/services/services-thumb-06.jpg",
    name: "Genetics",
    icon: "flaticon-dna",
    color: "pink-round",
  },
];

export default ServiceDataHomeThree;
